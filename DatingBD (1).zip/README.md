
# Dating BD Website

This is the starter for the Dating BD Coming Soon page.

## Structure
- index.html (main page)
- css/style.css (styles)
- js/script.js (scripts)
- assets/ (images and media)
